"""
The chatbot engine orchestrates the full pipeline:

  user message
      -> escalation-confirmation check (was the bot just waiting on a yes/no?)
      -> preprocessing
      -> intent classification (Tier 1)
      -> confidence check
          -> high confidence: curated templated response
          -> low confidence: generative fallback (Tier 2), context-aware
      -> context update
      -> structured response returned to caller (API / UI)

This is the single object both api.py and app.py depend on, so business
logic lives in exactly one place.
"""

from src.config import (
    CENTROIDS_PATH,
    CLASSIFIER_PATH,
    CONFIDENCE_THRESHOLD,
    FALLBACK_TAG,
    HUMAN_AGENT_CONNECT_MESSAGE,
    HUMAN_AGENT_DECLINE_MESSAGE,
    INTENTS_PATH,
    LABEL_ENCODER_PATH,
    MAX_CONTEXT_TURNS,
    SAFE_FALLBACK_MESSAGE,
)
from src.context_manager import ContextManager
from src.intent_classifier import IntentClassifier
from src.preprocessing import clean_text, extract_order_id, is_affirmative, is_negative
from src.response_generator import FallbackGenerator, IntentResponseSelector


class ChatbotEngine:
    def __init__(self):
        # --- Load Tier 1: intent classifier ---
        self.classifier = IntentClassifier()
        self.classifier.load(CLASSIFIER_PATH, LABEL_ENCODER_PATH, CENTROIDS_PATH)

        # --- Load response systems ---
        self.response_selector = IntentResponseSelector(INTENTS_PATH)
        self.fallback_generator = FallbackGenerator()

        # --- Context memory ---
        self.context_manager = ContextManager(max_turns=MAX_CONTEXT_TURNS)

        self.confidence_threshold = CONFIDENCE_THRESHOLD

    def process_message(self, session_id: str, message: str) -> dict:
        """
        Processes a single user message end-to-end and returns a
        structured result describing what happened, so the frontend
        can show intent/confidence for transparency (great for demos).
        """
        context = self.context_manager.get_or_create(session_id)
        context.add_user_message(message)

        cleaned_message = clean_text(message)

        # --- Escalation-confirmation follow-up check -----------------------
        # If the bot's PREVIOUS turn just asked "connect you with a human
        # agent?", this turn is very likely a short yes/no answer to that
        # specific question, not a fresh topic. Handling this explicitly
        # avoids re-running "yes" through the general intent classifier,
        # where a one-word message has no real semantic content to classify
        # and previously fell through to a confused generative response.
        if context.awaiting_escalation_confirmation:
            context.awaiting_escalation_confirmation = False  # answered now

            if is_affirmative(cleaned_message):
                response_text = HUMAN_AGENT_CONNECT_MESSAGE
                context.add_bot_message(response_text)
                context.last_intent = "human_agent"
                return {
                    "session_id": session_id,
                    "intent": "human_agent",
                    "confidence": 1.0,
                    "response": response_text,
                    "used_fallback": False,
                    "escalate_to_human": True,
                }

            if is_negative(cleaned_message):
                response_text = HUMAN_AGENT_DECLINE_MESSAGE
                context.add_bot_message(response_text)
                context.last_intent = "escalation_declined"
                return {
                    "session_id": session_id,
                    "intent": "escalation_declined",
                    "confidence": 1.0,
                    "response": response_text,
                    "used_fallback": False,
                    "escalate_to_human": False,
                }

            # Ambiguous reply (not a clear yes/no) — fall through to normal
            # processing below rather than guessing at the user's intent.

        order_id = extract_order_id(message)

        intent, confidence = self.classifier.predict(cleaned_message)

        used_fallback = False
        escalate = False

        if confidence >= self.confidence_threshold:
            # Tier 1: confident, curated response
            response_text = self.response_selector.select(
                intent, slots={"order_id": order_id}
            )
            if intent == "human_agent":
                escalate = True
        else:
            # Tier 2: not confident enough, use generative fallback
            used_fallback = True
            intent = FALLBACK_TAG
            history_text = context.get_history_text(max_turns=2)
            response_text = self.fallback_generator.generate(
                history_text, message
            )
            # If the fallback ended up returning the safe "I'm not sure,
            # want a human agent?" message, remember that we just asked
            # this question so the NEXT message can be interpreted as the
            # answer to it (handled at the top of this method).
            if response_text == SAFE_FALLBACK_MESSAGE:
                context.awaiting_escalation_confirmation = True

        context.add_bot_message(response_text)
        context.last_intent = intent

        return {
            "session_id": session_id,
            "intent": intent,
            "confidence": round(confidence, 4),
            "response": response_text,
            "used_fallback": used_fallback,
            "escalate_to_human": escalate,
        }

    def reset_session(self, session_id: str) -> None:
        self.context_manager.reset_session(session_id)
